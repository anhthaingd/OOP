import javax.swing.*;

public class FirstDialog {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null,"Hello world! How are you?");
        System.exit(0);
    }
}
